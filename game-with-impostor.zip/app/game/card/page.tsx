"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useGameStore } from "@/lib/game/store"
import { Eye, EyeOff, ArrowRight, Skull, MessageCircle } from "lucide-react"

export default function CardRevealPage() {
  const [isRevealed, setIsRevealed] = useState(false)
  const router = useRouter()
  const { 
    roomCode, 
    players, 
    theme, 
    currentRevealingPlayer, 
    status,
    markCardSeen, 
    nextRevealingPlayer 
  } = useGameStore()

  const currentPlayer = players[currentRevealingPlayer]

  useEffect(() => {
    if (!roomCode) {
      router.push("/")
    }
  }, [roomCode, router])

  useEffect(() => {
    if (status === "playing") {
      router.push("/game/round")
    }
  }, [status, router])

  const handleReveal = () => {
    setIsRevealed(true)
    if (currentPlayer) {
      markCardSeen(currentPlayer.id)
    }
  }

  const handleNext = () => {
    setIsRevealed(false)
    nextRevealingPlayer()
  }

  if (!roomCode || !currentPlayer) {
    return null
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {currentPlayer.isImpostor ? (
          <div className="absolute inset-0 bg-destructive/5" />
        ) : (
          <div className="absolute inset-0 bg-accent/5" />
        )}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 flex flex-col items-center gap-6 w-full max-w-sm">
        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-1">
            Jogador {currentRevealingPlayer + 1} de {players.length}
          </p>
          <h1 className="text-2xl font-bold text-foreground">
            {currentPlayer.name}
          </h1>
          <p className="text-muted-foreground mt-1">
            É a sua vez de ver sua carta
          </p>
        </div>

        <Card className={`w-full aspect-[3/4] relative overflow-hidden transition-all duration-500 ${
          isRevealed 
            ? currentPlayer.isImpostor 
              ? "bg-destructive/10 border-destructive/50" 
              : "bg-accent/10 border-accent/50"
            : "bg-card border-border"
        }`}>
          <CardContent className="flex flex-col items-center justify-center h-full p-6">
            {!isRevealed ? (
              <div className="flex flex-col items-center gap-6 text-center">
                <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center">
                  <EyeOff className="w-10 h-10 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-lg text-muted-foreground">
                    Carta escondida
                  </p>
                  <p className="text-sm text-muted-foreground/70 mt-2">
                    Certifique-se que apenas você está vendo a tela
                  </p>
                </div>
                <Button
                  onClick={handleReveal}
                  size="lg"
                  className="mt-4 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <Eye className="w-5 h-5 mr-2" />
                  Revelar Carta
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-6 text-center animate-in fade-in zoom-in duration-300">
                {currentPlayer.isImpostor ? (
                  <>
                    <div className="w-24 h-24 rounded-full bg-destructive/20 flex items-center justify-center">
                      <Skull className="w-12 h-12 text-destructive" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-bold text-destructive">
                        IMPOSTOR
                      </h2>
                      <p className="text-muted-foreground mt-3 text-balance">
                        Você não sabe o tema. Tente se passar por um jogador normal sem ser descoberto!
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-24 h-24 rounded-full bg-accent/20 flex items-center justify-center">
                      <MessageCircle className="w-12 h-12 text-accent" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground uppercase tracking-wider">
                        O tema é
                      </p>
                      <h2 className="text-3xl font-bold text-accent mt-2">
                        {theme}
                      </h2>
                      <p className="text-muted-foreground mt-3 text-balance">
                        Fale sobre o tema sem revelar demais para o impostor!
                      </p>
                    </div>
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {isRevealed && (
          <Button
            onClick={handleNext}
            size="lg"
            className="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-primary-foreground animate-in slide-in-from-bottom duration-300"
          >
            {currentRevealingPlayer < players.length - 1 ? (
              <>
                Próximo Jogador
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            ) : (
              <>
                Começar Rodada
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        )}

        <p className="text-xs text-muted-foreground text-center">
          Passe o dispositivo para o próximo jogador com cuidado
        </p>
      </div>
    </main>
  )
}
