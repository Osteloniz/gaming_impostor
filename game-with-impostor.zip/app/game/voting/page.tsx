"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useGameStore } from "@/lib/game/store"
import { Vote, User, Check, ArrowRight } from "lucide-react"

export default function VotingPage() {
  const [currentVoterIndex, setCurrentVoterIndex] = useState(0)
  const [selectedVote, setSelectedVote] = useState<string | null>(null)
  const [hasVoted, setHasVoted] = useState(false)
  const router = useRouter()
  const { 
    roomCode, 
    players, 
    status,
    castVote 
  } = useGameStore()

  const currentVoter = players[currentVoterIndex]

  useEffect(() => {
    if (!roomCode) {
      router.push("/")
    }
  }, [roomCode, router])

  useEffect(() => {
    if (status === "results") {
      router.push("/game/results")
    }
  }, [status, router])

  const handleConfirmVote = () => {
    if (!selectedVote || !currentVoter) return
    castVote(currentVoter.id, selectedVote)
    setHasVoted(true)
  }

  const handleNextVoter = () => {
    setCurrentVoterIndex(prev => prev + 1)
    setSelectedVote(null)
    setHasVoted(false)
  }

  const otherPlayers = players.filter(p => p.id !== currentVoter?.id)

  if (!roomCode || !currentVoter) {
    return null
  }

  return (
    <main className="min-h-screen flex flex-col items-center p-4 bg-background">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-destructive/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 flex flex-col items-center gap-6 w-full max-w-md pt-8">
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Vote className="w-6 h-6 text-primary" />
            <h1 className="text-2xl font-bold text-foreground">Votação</h1>
          </div>
          <p className="text-muted-foreground">
            Votante {currentVoterIndex + 1} de {players.length}
          </p>
        </div>

        <Card className="w-full bg-primary/10 border-primary/30">
          <CardContent className="flex flex-col items-center gap-2 py-6">
            <p className="text-sm text-muted-foreground">É a vez de</p>
            <h2 className="text-2xl font-bold text-foreground">
              {currentVoter.name}
            </h2>
            <p className="text-sm text-muted-foreground">votar</p>
          </CardContent>
        </Card>

        {!hasVoted ? (
          <>
            <Card className="w-full bg-card/80 backdrop-blur-sm border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-card-foreground">
                  Quem você acha que é o impostor?
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-2">
                {otherPlayers.map((player) => (
                  <button
                    key={player.id}
                    onClick={() => setSelectedVote(player.id)}
                    className={`flex items-center gap-3 p-4 rounded-lg transition-all ${
                      selectedVote === player.id
                        ? "bg-destructive/20 border-2 border-destructive/50"
                        : "bg-secondary/50 border-2 border-transparent hover:bg-secondary"
                    }`}
                  >
                    <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                      selectedVote === player.id
                        ? "bg-destructive/30 text-destructive"
                        : "bg-muted text-muted-foreground"
                    }`}>
                      <User className="w-5 h-5" />
                    </div>
                    <span className={`font-medium ${
                      selectedVote === player.id
                        ? "text-foreground"
                        : "text-muted-foreground"
                    }`}>
                      {player.name}
                    </span>
                    {selectedVote === player.id && (
                      <Check className="w-5 h-5 text-destructive ml-auto" />
                    )}
                  </button>
                ))}
              </CardContent>
            </Card>

            <Button
              onClick={handleConfirmVote}
              disabled={!selectedVote}
              size="lg"
              className="w-full h-14 text-lg bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            >
              <Vote className="w-5 h-5 mr-2" />
              Confirmar Voto
            </Button>
          </>
        ) : (
          <div className="flex flex-col items-center gap-6 w-full">
            <Card className="w-full bg-accent/10 border-accent/30">
              <CardContent className="flex flex-col items-center gap-4 py-8">
                <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center">
                  <Check className="w-8 h-8 text-accent" />
                </div>
                <div className="text-center">
                  <h3 className="text-xl font-bold text-foreground">
                    Voto registrado!
                  </h3>
                  <p className="text-muted-foreground mt-2">
                    Passe o dispositivo para o próximo jogador
                  </p>
                </div>
              </CardContent>
            </Card>

            {currentVoterIndex < players.length - 1 ? (
              <Button
                onClick={handleNextVoter}
                size="lg"
                className="w-full h-14 text-lg bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Próximo Votante
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            ) : (
              <p className="text-center text-muted-foreground animate-pulse">
                Todos votaram! Carregando resultados...
              </p>
            )}
          </div>
        )}

        <p className="text-xs text-muted-foreground text-center">
          Certifique-se que apenas você está vendo a tela ao votar
        </p>
      </div>
    </main>
  )
}
