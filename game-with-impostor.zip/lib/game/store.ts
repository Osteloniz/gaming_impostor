"use client"

import { create } from 'zustand'
import type { GameState, Player } from './types'
import { 
  generateRoomCode, 
  generatePlayerId, 
  shuffleArray, 
  getRandomTheme 
} from './types'

interface GameStore extends GameState {
  // Actions
  createRoom: (hostName: string) => void
  joinRoom: (playerName: string) => void
  addPlayer: (name: string) => void
  removePlayer: (playerId: string) => void
  startGame: () => void
  markCardSeen: (playerId: string) => void
  nextRevealingPlayer: () => void
  nextTurn: () => void
  castVote: (voterId: string, votedForId: string) => void
  getResults: () => { impostorName: string; theme: string; votes: Record<string, number>; impostorCaught: boolean }
  resetGame: () => void
  resetToLobby: () => void
}

const initialState: GameState = {
  roomCode: '',
  status: 'lobby',
  players: [],
  theme: null,
  impostorId: null,
  turnOrder: [],
  currentTurnIndex: 0,
  currentRevealingPlayer: 0,
}

export const useGameStore = create<GameStore>((set, get) => ({
  ...initialState,

  createRoom: (hostName: string) => {
    const hostId = generatePlayerId()
    const host: Player = {
      id: hostId,
      name: hostName,
      isHost: true,
      isImpostor: false,
      hasSeenCard: false,
      votedFor: null,
    }
    set({
      roomCode: generateRoomCode(),
      status: 'lobby',
      players: [host],
      theme: null,
      impostorId: null,
      turnOrder: [],
      currentTurnIndex: 0,
      currentRevealingPlayer: 0,
    })
  },

  joinRoom: (playerName: string) => {
    const { players } = get()
    const newPlayer: Player = {
      id: generatePlayerId(),
      name: playerName,
      isHost: false,
      isImpostor: false,
      hasSeenCard: false,
      votedFor: null,
    }
    set({ players: [...players, newPlayer] })
  },

  addPlayer: (name: string) => {
    const { players } = get()
    const newPlayer: Player = {
      id: generatePlayerId(),
      name,
      isHost: players.length === 0,
      isImpostor: false,
      hasSeenCard: false,
      votedFor: null,
    }
    set({ players: [...players, newPlayer] })
  },

  removePlayer: (playerId: string) => {
    const { players } = get()
    const updatedPlayers = players.filter(p => p.id !== playerId)
    // If host is removed, make first player the new host
    if (updatedPlayers.length > 0 && !updatedPlayers.some(p => p.isHost)) {
      updatedPlayers[0].isHost = true
    }
    set({ players: updatedPlayers })
  },

  startGame: () => {
    const { players } = get()
    if (players.length < 3) return

    // Select random impostor
    const impostorIndex = Math.floor(Math.random() * players.length)
    const impostorId = players[impostorIndex].id

    // Update players with impostor role
    const updatedPlayers = players.map((p, index) => ({
      ...p,
      isImpostor: index === impostorIndex,
      hasSeenCard: false,
      votedFor: null,
    }))

    // Generate turn order
    const turnOrder = shuffleArray(players.map(p => p.id))

    set({
      status: 'revealing',
      players: updatedPlayers,
      theme: getRandomTheme(),
      impostorId,
      turnOrder,
      currentTurnIndex: 0,
      currentRevealingPlayer: 0,
    })
  },

  markCardSeen: (playerId: string) => {
    const { players } = get()
    const updatedPlayers = players.map(p =>
      p.id === playerId ? { ...p, hasSeenCard: true } : p
    )
    set({ players: updatedPlayers })
  },

  nextRevealingPlayer: () => {
    const { currentRevealingPlayer, players } = get()
    const nextIndex = currentRevealingPlayer + 1
    
    if (nextIndex >= players.length) {
      // All players have seen their cards, move to playing
      set({ status: 'playing', currentRevealingPlayer: 0 })
    } else {
      set({ currentRevealingPlayer: nextIndex })
    }
  },

  nextTurn: () => {
    const { currentTurnIndex, turnOrder } = get()
    const nextIndex = currentTurnIndex + 1
    
    if (nextIndex >= turnOrder.length) {
      // All players have had their turn, move to voting
      set({ status: 'voting', currentTurnIndex: 0 })
    } else {
      set({ currentTurnIndex: nextIndex })
    }
  },

  castVote: (voterId: string, votedForId: string) => {
    const { players } = get()
    const updatedPlayers = players.map(p =>
      p.id === voterId ? { ...p, votedFor: votedForId } : p
    )
    set({ players: updatedPlayers })

    // Check if all votes are in
    if (updatedPlayers.every(p => p.votedFor !== null)) {
      set({ status: 'results' })
    }
  },

  getResults: () => {
    const { players, theme, impostorId } = get()
    const impostor = players.find(p => p.id === impostorId)
    
    // Count votes
    const votes: Record<string, number> = {}
    players.forEach(p => {
      if (p.votedFor) {
        votes[p.votedFor] = (votes[p.votedFor] || 0) + 1
      }
    })

    // Find most voted player
    let maxVotes = 0
    let mostVotedId = ''
    Object.entries(votes).forEach(([playerId, voteCount]) => {
      if (voteCount > maxVotes) {
        maxVotes = voteCount
        mostVotedId = playerId
      }
    })

    return {
      impostorName: impostor?.name || 'Desconhecido',
      theme: theme || 'Desconhecido',
      votes,
      impostorCaught: mostVotedId === impostorId,
    }
  },

  resetGame: () => {
    set(initialState)
  },

  resetToLobby: () => {
    const { players, roomCode } = get()
    const resetPlayers = players.map(p => ({
      ...p,
      isImpostor: false,
      hasSeenCard: false,
      votedFor: null,
    }))
    set({
      status: 'lobby',
      players: resetPlayers,
      roomCode,
      theme: null,
      impostorId: null,
      turnOrder: [],
      currentTurnIndex: 0,
      currentRevealingPlayer: 0,
    })
  },
}))
