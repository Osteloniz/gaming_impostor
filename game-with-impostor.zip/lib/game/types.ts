export type GameStatus = 
  | 'lobby' 
  | 'revealing' 
  | 'playing' 
  | 'voting' 
  | 'results'

export interface Player {
  id: string
  name: string
  isHost: boolean
  isImpostor: boolean
  hasSeenCard: boolean
  votedFor: string | null
}

export interface GameState {
  roomCode: string
  status: GameStatus
  players: Player[]
  theme: string | null
  impostorId: string | null
  turnOrder: string[]
  currentTurnIndex: number
  currentRevealingPlayer: number
}

export const THEMES = [
  "Praia",
  "Filmes de terror",
  "Pizza",
  "Super-heróis",
  "Videogames",
  "Festas de aniversário",
  "Carros",
  "Animais de estimação",
  "Viagens internacionais",
  "Esportes radicais",
  "Música pop",
  "Comida japonesa",
  "Natal",
  "Halloween",
  "Casamentos",
  "Academia",
  "Redes sociais",
  "Séries de TV",
  "Futebol",
  "Chocolate",
  "Café da manhã",
  "Parques de diversão",
  "Camping",
  "Churrasco",
  "Anos 80",
  "Escola",
  "Trabalho remoto",
  "Festas juninas",
  "Carnaval",
  "Cinema",
]

export function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 4; i++) {
    code += chars[Math.floor(Math.random() * chars.length)]
  }
  return code
}

export function generatePlayerId(): string {
  return Math.random().toString(36).substring(2, 9)
}

export function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array]
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
  }
  return shuffled
}

export function getRandomTheme(): string {
  return THEMES[Math.floor(Math.random() * THEMES.length)]
}
